jQuery().ready(function() {
	//set colorpicker for input with class mf_color_picker
	jQuery(":input.mf_color_picker").each( function(inputField){
		var editor_text = jQuery(this).attr('id');
		jQuery('#'+editor_text).SevenColorPicker();
	});
});