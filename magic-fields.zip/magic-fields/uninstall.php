<?php

/**
 * Uninstall file for Magic Fields
 * 
 * @todo do this page :p
 *
 */

