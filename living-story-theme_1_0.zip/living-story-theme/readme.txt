Thank you for downloading the Living Stories Wordpress theme!

For information on how to install and use this plugin, please consult
the documentation at 
http://code.google.com/p/living-stories/wiki/WordpressInstallation

Note about the license:
This plugin is licensed under the GPL as required
(See http://wordpress.org/development/2009/07/themes-are-gpl-too/)
However, the GWT code that runs on the page shares the license of the rest
of the code in this project, Apache 2.0.

