<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>

	<div id="content" class="narrowcolumn">

		<h2 class="center">Error 404 - Not Found</h2>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>